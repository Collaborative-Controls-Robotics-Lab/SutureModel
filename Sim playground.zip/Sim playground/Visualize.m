function [hFig, paramTurns, hEM, colorMat, colorField, gi_vec] = Visualize(numCoilTurns, numEMs, rDom, ell_i, rho_i, theta_i, r_i, gi, linpar)


paramTurns = linspace(0,1,numCoilTurns);
XYGrid = linspace(-rDom,rDom,51);
[MESH_X,MESH_Y] = meshgrid(XYGrid);
rp_vec = [MESH_X(:),MESH_Y(:)].';
rp_vec(:,vecnorm(rp_vec)>rDom) = [];
hFig =  figure(1);
clf
set(hFig,'color','w','Position',[10 50 1280 720])
hEM = gobjects(numCoilTurns,numEMs);
colorMat = 0.8*hsv(numEMs);
colorField = ones(size(rp_vec,2),3);
gi_vec = zeros(2,size(rp_vec,2),numEMs+1);
axis equal off
hold on

for ii = 1:numEMs
    hEM(end:-1:1,ii) = plot(r_i(1,ii) + bsxfun(@plus,cos(theta_i(ii))*(ell_i*(paramTurns(end:-1:1)-0.5)),(1-(8/9*cos(theta_i(ii))^2))*rho_i*cos(2*pi*linpar.')),r_i(2,ii)  + bsxfun(@plus,sin(theta_i(ii))*(ell_i*(paramTurns(end:-1:1)-0.5)),(1-(8/9*sin(theta_i(ii))^2))*rho_i*sin(2*pi*linpar.')),'Color',0.01*[43.14, 23.92, 20.39],'LineWidth',1.5);
    gi_vec(:,:,ii) = gi(rp_vec,r_i(:,ii));%(mu0*rho_i*N_i/2*% - rp_vec);
end
gi_vec(:,:,numEMs+1) = sum(gi_vec(:,:,1:end-1),3)/numEMs;
%hBi = cquiver(rp_vec(1,:),rp_vec(2,:),gi_vec(1,:,numEMs+1)./vecnorm(gi_vec(:,:,numEMs+1)),gi_vec(2,:,numEMs+1)./vecnorm(gi_vec(:,:,numEMs+1)),colorField);
hDom = plot(rDom*cos(2*pi*linpar),rDom*sin(2*pi*linpar),'k','LineWidth',2);

end