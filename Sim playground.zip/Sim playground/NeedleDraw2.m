function [transformNeedleBody, hNeedle, compVis, transformCompVisBody, hCompVis] = NeedleDraw2(ell_p, rho_p, linpar,needleXY,needleT)

needleTVel = 0;
compVisBody = [...
    [-ell_p/2; 2*rho_p]*(1-linpar(1:end-1))+[ ell_p/2; 2*rho_p]*(linpar(1:end-1)),...
    [ ell_p/2; 2*rho_p]*(1-linpar(1:end-1))+[ ell_p/2;-2*rho_p]*(linpar(1:end-1)),... % Square tip
    ...%[ ell_p/2; 0]+[3*2*rho_p*cos(pi/2*(1-linpar(1:end-1))-pi/2*(linpar(1:end-1)));2*rho_p*sin(pi/2*(1-linpar(1:end-1))-pi/2*(linpar(1:end-1)))],... % Rounded tip
    [ ell_p/2;-2*rho_p]*(1-linpar(1:end-1))+[-ell_p/2;-2*rho_p]*(linpar(1:end-1)),...
    [-ell_p/2;-2*rho_p]*(1-linpar(1:end-1))+[-ell_p/2; 2*rho_p]*(linpar(1:end-1))];
needleBody = [...
    [-ell_p/2; rho_p]*(1-linpar(1:end-1))+[ ell_p/2; rho_p]*(linpar(1:end-1)),...
    ...%[ ell_p/2; rho_p]*(1-linpar(1:end-1))+[ ell_p/2;-rho_p]*(linpar(1:end-1)),... % Square tip
    [ ell_p/2; 0]+[3*rho_p*cos(pi/2*(1-linpar(1:end-1))-pi/2*(linpar(1:end-1)));rho_p*sin(pi/2*(1-linpar(1:end-1))-pi/2*(linpar(1:end-1)))],... % Rounded tip
    [ ell_p/2;-rho_p]*(1-linpar(1:end-1))+[-ell_p/2;-rho_p]*(linpar(1:end-1)),...
    [-ell_p/2;-rho_p]*(1-linpar(1:end-1))+[-ell_p/2; rho_p]*(linpar(1:end-1))];
transformNeedleBody = @(XY,T) bsxfun(@plus,XY,[cos(T),-sin(T);sin(T),cos(T)]*needleBody);
transformCompVisBody = @(XY,T) bsxfun(@plus,XY,[cos(T),-sin(T);sin(T),cos(T)]*compVisBody);
numNeedles = 1;
seedrng = 100;
rng(seedrng)
needleXYVel = zeros(size(needleXY));
hNeedle = gobjects(numNeedles,1);
hCompVis = gobjects(numNeedles,1);
for ii = 1:numNeedles
    needle = transformNeedleBody(needleXY(:,ii),needleT(ii));
    compVis = transformNeedleBody(needleXY(:,ii),needleT(ii));
    hNeedle(ii) = patch('xdata',needle(1,:),'ydata',needle(2,:),'LineWidth',0.5,'EdgeColor','k','FaceColor',0.5*[1 1 1],'EdgeAlpha',1,'FaceAlpha',1);
    hCompVis(ii) = patch('xdata',compVis(1,:),'ydata',compVis(2,:),'LineStyle','none','FaceColor',[0.5 0.75 1],'FaceAlpha',0.75);
end

end