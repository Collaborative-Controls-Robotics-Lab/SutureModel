function main_joystick()

% Authors: Kimia Forghani, Yancy Diaz-Mercado
%
% Date Created: 02/14/2025
%
% Copyright (c) 2025
% Collaborative Controls and Robotics Laboratory
% University of Maryland, College Park
%
% All rights reserved.

clc
clear
warning('off', 'all');

joy = vrjoystick(1);  % Use 1 if it's your first joystick

% Global variable to track key presses
%     global pressedKeys;
%     pressedKeys = struct('w', false, 'a', false, 's', false, 'd', false);

% Create a figure for capturing key presses
    hFig = figure;
%     set(hFig, 'KeyPressFcn', @keyPress);
%     set(hFig, 'KeyReleaseFcn', @keyRelease); % Handle key release

%init params
    timeStep = 0.048;           %Change this based on hardware
    n = 30;                     %Number of nodes in the chain
    ell_thread = 200;           %Thread length
    deltaL=ell_thread/(n-1);
    separationEnforcementGain = 10;
    SafetyDistance = 0.5;

%% Electromagnet (EM) parameters pnly for visualization
rDom = 80; %[m]
numEMs = 4;
wBox = 170; %[m] width of box made by EMs ------->should be updated
ell_i=50; %based on suraj mecc paper
rEM = wBox/2 + ell_i/2; % [m] distance to center of EMs from center of dish
numCoilTurns = 29; %based on suraj mecc paper
rho_i =40; %based on suraj mecc paper
theta_i = 0:(pi/2):(2*pi-pi/2); % [rad] direction of EMs from center
X_i = rEM*[cos(theta_i);sin(theta_i)]; % [m] position of each EM 2X4
linpar = linspace(0,1,100);

%% Workspace Drawing
gi = @(rp,ri) (1./vecnorm(rp-ri).^3).*bsxfun(@minus,ri, 3* bsxfun(@times,(rp-ri),ri.'*(rp-ri))./(vecnorm(rp-ri).^2))/rEM; % [1/m^3]
[hFig, paramTurns, hEM, colorMat, colorField, gi_vec] = Visualize(numCoilTurns, numEMs, rDom, ell_i, rho_i, theta_i, X_i, gi, linpar);
drawnow

%% Magnetic needle parameters (assuming Neodyum-Iron-Boron (NdFeB) N52)
rho_p = 0.5; %[m] outer radius of the needle
ell_p = 15;  %[m] length of the needle
%% Needle Drawing
% Initial position of the needle
    needle_pos = [0; -40];          %[x; y]
    needle_pos_temp = needle_pos;

needleXY(1,1)=needle_pos(1); needleXY(2,1)=needle_pos(2); needleT = pi/2; 

[transformNeedleBody, hNeedle, compVis, transformCompVisBody, hCompVis] = NeedleDraw2(ell_p, rho_p, linpar,needleXY,needleT);
delete(hCompVis)

%%

    initSep = 0.99*deltaL;          %Initial distanc between each two nodes
    initPos = needle_pos';
    threadXY = [ones(n, 1)*initPos(1,1)  ,  (initPos(1,2)-initSep: -initSep: (n-1)*-initSep+initPos(1,2)-initSep)'];
    threadXY=threadXY'; %size(threadXY) = 2 X n

   
    hThread = plot(threadXY(1,:), threadXY(2,:) , '-o','LineWidth',2,'MarkerSize', 1, 'MarkerFaceColor', 0.75*[1 1 1],'Color', 0.5*[1 1 1]); % Suture initially rest on x axis 
    axis([-130 130 -130 130 -5 5]);
    axis off; 
    set(gcf, 'Color', 'w');
    
%% Visualize Abdominal Wall and Inguinal Ring
%Visualization parameters
    rho_p = 0.00071/2*1000; %[mm] outer radius of the needle
    percentageFromEdge2Ring = 0.85;
%Hernia visualization
    [~,abdominalWall,~] = visualizeInguinalRing('NeedleRadius',2*rho_p,'FractionEdgeToRing',percentageFromEdge2Ring);

%Obstacle Triangulation
    tri_vertices{1} = triangles_vertices_delaunay(abdominalWall{1}); %project point method
    tri_vertices{2} = triangles_vertices_delaunay(abdominalWall{2}); %project point method
    tri_vertices{3} = triangles_vertices_delaunay(abdominalWall{3}); %project point method

%%
%Choose your barrier function

%Without Stiffness Lyapunov Function: suitable for silk suture
%     barrierCertificate = create_si_connectivity_barrier_certificate_with_obstacles('MaxSeparation',deltaL,'SafetyDistance', SafetyDistance,'BarrierGain',separationEnforcementGain,'N',n,'tri_verices',tri_vertices);

%With Stiffness Lyapunov Function: suitable for Polyamide suture
    barrierCertificate = create_si_connectivity_barrier_certificate_with_obstacles_stiff('MaxSeparation',deltaL,'SafetyDistance', SafetyDistance,'BarrierGain',separationEnforcementGain,'N',n,'tri_verices',tri_vertices);

%%
%initial thread vlocity
    threadXYVel = zeros(2,n); %Initially stationary 
j=1;
tic; %start timer
while 1

    threadXYVel = 0.8* threadXYVel; %Damping effect Beta=0.9
    needle_step = getNeedleStep(); % Compute the movement based on active keys
    du = (needle_step)./timeStep;   %Needle velocity based on user input
   
%************************ Thread Update Start *************************
    [threadXYVel, duC, ~, Btis] = barrierCertificate(threadXYVel,threadXY,needle_pos_temp,du);

%CLF 
    if j>1
        % slows down needle if two consecutive obs
        Btis = Btis*1e-3;
    
        % Define the lengths of the sections
        n1 = n+1;
    
        % Extract the three parts of the vector
        Btis_part1 = Btis(1:n1);                   % First part
        Btis_part2 = Btis(n1+1:2*n1);              % Second part
        Btis_part3 = Btis(2*n1+1:3*n1);            % Third part
    
        Bthresh = 0.03;
        velthresh = 4;
        % Check if Btis(j, i) in any two of the three parts is < Bthresh
        condition1 = (Btis_part1 < Bthresh & Btis_part2 < Bthresh) | ...
                     (Btis_part1 < Bthresh & Btis_part3 < Bthresh) | ...
                     (Btis_part2 < Bthresh & Btis_part3 < Bthresh);
                 if any(condition1)  
                        % Find the index where the condition is true
                        index = find(condition1, 2); % Find the first index where condition1 is true
        
                        % Check if condition1 is true for any element
                        if ~isempty(index) && any(arrayfun(@(i) norm(threadXYVel(:, mod(i,n)+1)), index) > velthresh) 
                            duC = duC * 0.9^sum(condition1);
                            threadXYVel = threadXYVel* 0.9^sum(condition1);
                            hThread.Color = [1, 165/255 * (13 - sum(condition1)) / 12,0]; %orange
                        else 
                            hThread.Color = [0,0.2,1]; %blue
                        end
        
                 else
                         hThread.Color = [0,1,0]; %green
                 end
    end

    %Update thread visual
    [threadXY, threadXYVel, hThread ,needle_pos_temp] = ThreadUpdateBarrier(threadXY, threadXYVel, timeStep, hThread,needle_pos_temp, duC);
    % Compute which nodes are inside the circular domain
    in_domain = vecnorm(threadXY).^2 <= (1.06*rDom)^2;
    
    % Only plot points inside rDom
    visibleX = threadXY(1, in_domain);
    visibleY = threadXY(2, in_domain);
    
    % Update the plot with only the visible part
    set(hThread, 'XData', visibleX, 'YData', visibleY);
    
    %************************* Thread Update End **************************

    %Update needle 
    needleT=atan2(needle_pos_temp(2)-threadXY(2,1),needle_pos_temp(1)-threadXY(1,1));
    needle = transformNeedleBody(needle_pos_temp,needleT);
    set(hNeedle(1),'XData',needle(1,:),'yData',needle(2,:))
    
    % Update the figure window 
    drawnow;  
%%
         elapsedTime = toc;  % Check the elapsed time
       
    if elapsedTime < timeStep
        pause(timeStep - elapsedTime);  % Adjust the pause to maintain consistent timing
    else
        disp(elapsedTime)
    end
  tic;  % Reset timer after each loop iteration

j=j+1;
end    
end

%% Function to compute the needle step based on active keys
function step = getNeedleStep()
    persistent joy;
    if isempty(joy)
        joy = vrjoystick(1);
    end

    step_size = 0.4; % Can be changed
    [axes, ~] = read(joy); % axes = [x-axis, y-axis, ...]

    % PS3 left stick: horizontal = axes(1), vertical = axes(2)
    x_val = axes(1);  % Left/right
    y_val = -axes(2); % Up/down (invert y-axis if needed)

    % Deadzone to avoid drift
    deadzone = 0.1;
    if abs(x_val) < deadzone
        x_val = 0;
    end
    if abs(y_val) < deadzone
        y_val = 0;
    end

    % Compute scaled step
    raw_step = step_size * [x_val; y_val];
    if norm(raw_step) > 0
        step = (raw_step / norm(raw_step)) * step_size;
    else
        step = [0; 0];
    end
end


 
